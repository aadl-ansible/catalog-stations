                                    Version 1.0

=================
Table of Contents
=================

   1.  Driver installation options
       1.1  Installation using the .tar.Z package
       1.2  Installation using the .deb package
       1.3  Installation using the .rpm package

   2.  Driver uninstallation options
       2.1  Uninstallation if .tar.Z was used to install the package
       2.2  Uninstallation if .deb was used to install the package
       2.3  Uninstallation if .rpm was used to install the package

   3. Notes

** Some install options may not be applicable to your package. Refer to the
package filename extension that you have. It may be .tar.Z, .deb, or .rpm.


==============================
1. Driver installation options
==============================

   Choose your installation method depending on the type of package
   you downloaded.

   If you encounter problems with any of the following installation procedures,
   then uninstall the previous driver by performing the steps indicated
   in Section 2.
   

==========================================
1.1  Installation using the .tar.Z package
==========================================

  1.  Download the file.

  2.  If the package file is compressed, then extract the file by typing the
      command:

        uncompress PPD-Files-LMAEG.tar.Z

  3.  Untar the file in this directory via:

        tar -xvf PPD-Files-LMAEG.tar

  4.  Change to the ppd_file directory via:

        cd ppd_files

  5.  Install the PPD files.

      a. Linux-Based CUPS
         ----------------
         Log in as a root user and then run the install script:

         ./install_ppd.sh

         See the Readme-CUPS.txt file for more information.

      b. Other CUPS installations
         ------------------------
         Copy the appropriate PPDs into the CUPS model directory 
         and restart CUPS.

         For CUPS version earlier than 1.4, use the PPD file(s) found in 
         ppd_files/GlobalPPD_1.2.

         For CUPS version 1.4 or later, use the PPD file(s) found in 
         ppd_files/GlobalPPD_1.4.

      c. OpenOffice/StarOffice
         -----------------------
         See the Readme-OpenOffice.txt file for more information.

      d. Other applications
         ------------------
         See the application documentation.


========================================
1.2  Installation using the .deb package
========================================

  1.  Download the file.

  2.  Install the package either by double-clicking the icon or through 
      the terminal using the following command:

      For 32-bit systems:
        dpkg -i lexmark-PPD-Files-LMAEG-1.0-1.i386.deb

      For 64-bit systems:
        dpkg -i lexmark-PPD-Files-LMAEG-1.0-1.amd64.deb

      Note: Administrative or 'root' access may be needed during the
            installation. You must have access to any of these accounts
            when prompted.

  Installation is complete.


========================================
1.3  Installation using the .rpm package
========================================

  1.  Download the file.

  2.  Install the package either by double-clicking the icon or through 
      the terminal using the following command:

      For 32-bit systems:
        rpm -ivh lexmark-PPD-Files-LMAEG-1.0-1.i386.rpm

      For 64-bit systems:
        rpm -ivh lexmark-PPD-Files-LMAEG-1.0-1.x86_64.rpm

      Note: Administrative or 'root' access may be needed during the
            installation. You must have access to any of these accounts
            when prompted.

  Installation is complete.


=================================
2.  Driver uninstallation options
=================================

   Choose your uninstallation method depending on the type of installation
   you used to install the driver software.


=============================================================
2.1  Uninstallation if .tar.Z was used to install the package
=============================================================

   If you chose to install the driver software using the PPD-Files-LMAEG.tar.Z
   package, then you need to manually remove the following files:

   a. Common UNIX Print Subsystem (CUPS)
      ----------------------------------
      Delete the PPD files from the following locations (if they exist) and restart CUPS.

        /usr/share/ppd/Lexmark_PPD/*
        /usr/share/cups/model/Lexmark_PPD/*
      

   b. Printer configuration (printtool or printconf) and Foomatic utilities
      ---------------------------------------------------------------------
      Delete the following files.
        
        /usr/share/foomatic/db/source/driver/Lexmark_PPD.xml 
        /usr/share/foomatic/db/source/opt/ppd-Lexmark_*
        /usr/share/foomatic/db/source/printer/Lexmark_*


===========================================================
2.2  Uninstallation if .deb was used to install the package
===========================================================

   Using your OS package manager, select the name of the package that
   you installed and remove it, or use the terminal by typing the
   following command:

      dpkg -r lexmark-ppd-Files-LMAEG


===========================================================
2.3  Uninstallation if .rpm was used to install the package
===========================================================

   Using your OS package manager, select the name of the package that
   you installed and remove it, or use the terminal by typing the
   following command:

   For 32-bit systems:
        rpm -e lexmark-PPD-Files-LMAEG-1.0-1.i386

   For 64-bit systems:
        rpm -e lexmark-PPD-Files-LMAEG-1.0-1.x86_64

   If these commands do not work because the architecture is not present in
   the package name, then use the following command:
        rpm -e lexmark-PPD-Files-LMAEG-1.0-1


=========
3. Notes:
=========

  1.Supported Languages
  ---------------------

     English (en)
     French (fr)
     German (de)
     Italian (it)
     Spanish (es)
     Korean (ko)
     Japanese (ja)
     Russian (ru)
     Polish (pl)
     Brazilian Portuguese (pt)
     Traditional Chinese (zh_TW) 
     Simplified Chinese (zh_CN)


  2.Supported Operating Systems
  -----------------------------

     Red Hat Enterprise Linux WS 4
     Red Hat Enterprise Linux WS 5
     Red Hat Enterprise Linux WS 6
     openSUSE Linux 11.3
     openSUSE Linux 11.4
     openSUSE Linux 12.1
     SUSE Linux Enterprise Desktop 10
     SUSE Linux Enterprise Desktop 11
     SUSE Linux Enterprise Server 10
     SUSE Linux Enterprise Server 11
     Debian GNU/Linux 5.0 (CUPS web only)
     Debian GNU/Linux 6.0 (CUPS web only)
     Ubuntu 11.04
     Ubuntu 11.10
     Ubuntu 12.04
     Linpus LINUX Desktop 9.6
     Red Flag Linux Desktop 6.0
     Fedora 15
     Mint 9
     Mint 10
     Mint 11
     Mint 12
     PCLinuxOS 2011.9


  3.File Names
  -----------------------------


     Printer Type                       Globalized PPD
     ------------                       ------------------

     Lexmark XM1100 Series                Lexmark_XM1100_Series.ppd
